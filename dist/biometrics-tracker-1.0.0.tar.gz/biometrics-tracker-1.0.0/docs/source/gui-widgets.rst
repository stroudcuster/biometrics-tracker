.. _gui-widgets:

biometrics_tracker.gui.widgets module
=====================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.gui.widgets
    :members:
    :show-inheritance:
