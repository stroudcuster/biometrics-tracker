.. _model-datapoints:

biometrics_tracker.model.datapoints module
==========================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.model.datapoints
    :members:
    :show-inheritance:

