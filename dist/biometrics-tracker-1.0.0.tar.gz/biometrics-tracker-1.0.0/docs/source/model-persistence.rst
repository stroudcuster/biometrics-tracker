.. _model-persistence:

biometrics_tracker.model.persistence module
===========================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.model.persistence
    :members:
    :show-inheritance:

