.. _config-createconfig:

biometrics_tracker.config-createconfig module
=============================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.config.createconfig
    :members:
    :show-inheritance:
