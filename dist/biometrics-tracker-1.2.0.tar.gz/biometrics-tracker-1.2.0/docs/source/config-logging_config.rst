.. _config-logging_config:

biometrics_tracker.config-logging_config module
===============================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.config.logging_config
    :members:
    :show-inheritance:
