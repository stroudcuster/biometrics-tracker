.. _gui-tk-gui:

biometrics_tracker.gui.tk_gui module
====================================

.. toctree::
    genindex

.. autosummary::
    :toctree: generated

.. automodule:: biometrics_tracker.gui.tk_gui
    :members:
    :show-inheritance:
