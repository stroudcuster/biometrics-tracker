.. _main-scheduler:

biometrics_tracker.main.scheduler module
========================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.main.scheduler
    :members:
    :show-inheritance:
