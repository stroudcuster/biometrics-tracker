.. _gui-validators:

biometrics_tracker.gui.validators module
========================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.gui.validators
    :members:
    :show-inheritance:
