.. _main:

biometrics_tracker.main module - desktop application entry point
================================================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.main.main
    :members:
    :show-inheritance:

