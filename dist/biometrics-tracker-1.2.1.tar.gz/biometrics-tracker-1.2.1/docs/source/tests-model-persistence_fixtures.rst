.. _tests-model-persistence_fixtures:

pytest tests.model.persistence_fixtures
=======================================

.. toctree::
    genindex

.. automodule:: tests.model.persistence_fixtures
    :members:
    :show-inheritance:
