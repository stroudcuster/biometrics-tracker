.. _config-json-handler:

biometrics_tracker.config.json_handler module
=============================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.config.json_handler
    :members:
    :show-inheritance:

