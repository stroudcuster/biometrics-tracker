.. _main-core:

biometrics_tracker.main.core module
===================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.main.core
    :members:
    :show-inheritance:
