.. _model-json-handler:

biometrics_tracker.model.json_handler module
============================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.model.json_handler
    :members:
    :show-inheritance:

