.. _model-uoms:

biometrics_tracker.model.uoms module
====================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.model.uoms
    :members:
    :show-inheritance:
