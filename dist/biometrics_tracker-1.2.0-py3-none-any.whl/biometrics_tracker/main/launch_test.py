import os

if __name__ == '__main__':
    os.system('python main.py --scheduled-entry "this is a test" "joe" "BG" "This is a note"')
    pass


