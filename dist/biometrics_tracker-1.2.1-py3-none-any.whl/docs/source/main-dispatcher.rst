.. _main-dispatcher:

biometrics_tracker.main.dispatcher module
=========================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.main.dispatcher
    :members:
    :show-inheritance:
