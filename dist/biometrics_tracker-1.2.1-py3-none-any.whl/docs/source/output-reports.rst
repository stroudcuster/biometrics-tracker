.. _output-reports:

biometrics_tracker.output.reports module
========================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.output.reports
    :members:
    :show-inheritance:

