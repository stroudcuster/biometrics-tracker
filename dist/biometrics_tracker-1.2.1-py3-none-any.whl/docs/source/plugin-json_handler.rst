.. _plugin-json_handler:

biometrics_tracker.plugin.json_handler module
=============================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.plugin.json_handler
    :members:
    :show-inheritance:

