.. _plugin-plugin:

biometrics_tracker.plugin.plugin module
=======================================

.. toctree::
    genindex

.. automodule:: biometrics_tracker.plugin.plugin
    :members:
    :show-inheritance:

